﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Media;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Instrument_Database_Test
{
    // Main winform that contols everything else
    // Also the main view into the instrument library
    public partial class Form1 : Form
    {
        // Whether the backup is going to be loaded
        public static bool backupStatus = false;

        // Staffing
        public static BindingList<Employees> currentStaff = new BindingList<Employees>();
        public static string currentEmployee;

        // Students
        public static BindingList<StudentData> students = new BindingList<StudentData>();

        // Filing
        public static string filepath = Application.StartupPath + "\\LibraryData";

        // Instruments
        public static BindingList<Instrument> allInstruments = new BindingList<Instrument>();
        //--//
        public static BindingList<Instrument> brass = new BindingList<Instrument>();
        public static BindingList<Instrument> percussion = new BindingList<Instrument>();
        public static BindingList<Instrument> strings = new BindingList<Instrument>();
        public static BindingList<Instrument> woodwinds = new BindingList<Instrument>();
        public static BindingList<Instrument> ema = new BindingList<Instrument>();
        public static BindingList<Instrument> microphone = new BindingList<Instrument>();
        public static BindingList<Instrument> mute = new BindingList<Instrument>();
        public static BindingList<Instrument> other = new BindingList<Instrument>();
        //--//
        public static List<BindingList<Instrument>> libraryRecords = new List<BindingList<Instrument>>()
            { allInstruments, brass, percussion, strings, woodwinds, ema, microphone, mute, other };
        
        // Search
        BindingList<Instrument> searchResults = new BindingList<Instrument>();

        // "Contructor"
        public Form1()
        {
            InitializeComponent();

            // Component that isn't finished yet but I don't want to delete it from this version
            studentButton.Visible = false;

            instrumentList.DataSource = allInstruments;
            dataView.Text = "";
            setFilepath();
            instrumentList.Select();
            // Sort instruments into their respective lists
            sortInstruments();
            searchBox.Select();

            // Select employee
            if (currentStaff.Count != 0)
            {
                employeeSelect eS = new employeeSelect();
                eS.ShowDialog();
            }
        }

        // Sets the instrument data overview
        private void instrumentList_SelectedIndexChanged(object sender, EventArgs e)
        {
            Instrument temp = (Instrument) instrumentList.SelectedItem;
            // Makes sure that an instrument is actually selected
            if(temp != null)
                dataView.Text = temp.returnData();
        }
        
        // Brings up the window to add instruments to the database
        private void addButton_Click(object sender, EventArgs e)
        {
            Data_Form instrumentWizard = new Data_Form();
            instrumentWizard.ShowDialog();
        }

        // Saves to a file
        private void saveButton_Click(object sender, EventArgs e)
        {
            if (allInstruments.Count>0)
            {
                // New XmlSerializer object
                XmlSerializer saver1 = new XmlSerializer(typeof(BindingList<Instrument>));
                // New TextWriter Object
                TextWriter writer1 = new StreamWriter(filepath + "\\InstrumentData.xml");
                // Write to file
                saver1.Serialize(writer1, allInstruments);
                writer1.Close();
            }
            
            if (students.Count>0)
            {
                XmlSerializer saver2 = new XmlSerializer(typeof(BindingList<StudentData>));
                // New TextWriter Object
                TextWriter writer2 = new StreamWriter(filepath + "\\StudentData.xml");
                // Write to file
                saver2.Serialize(writer2, students);
                writer2.Close();
            }

            if (students.Count > 0)
                saveEmployeeNames();

            SystemSounds.Beep.Play();
        }

        // Saves employee names to an xml file
        public static void saveEmployeeNames()
        {
            
            try
            {
                XmlSerializer saver3 = new XmlSerializer(typeof(BindingList<Employees>));
                // New TextWriter Object
                TextWriter writer3 = new StreamWriter(filepath + "\\Employees.xml");
                // Write to file
                saver3.Serialize(writer3, currentStaff);
                writer3.Close();
            }
            catch (Exception)
            { /* ToDo: Figure out what to do here when something is already using the file */

                XmlSerializer saver3 = new XmlSerializer(typeof(BindingList<Employees>));
                // New TextWriter Object
                TextWriter writer3 = new StreamWriter(filepath + "\\Employees.xml");
                // Write to file
                saver3.Serialize(writer3, currentStaff);
                writer3.Close();
            }
            
        }

        // Reads from file
        private void deserialize(int i)
        {
            switch (i)
            {
                // Serializes Instrument data
                case 0:
                    // Uses try in case there's nothing written to the file
                    try
                    {
                        // New deserializer
                        XmlSerializer loader = new XmlSerializer(typeof(BindingList<Instrument>));
                        // Using statement so that it automatically closes the file
                        using (TextReader reader = new StreamReader(filepath + "\\InstrumentData.xml"))
                            allInstruments = (BindingList<Instrument>)loader.Deserialize(reader);
                        instrumentList.DataSource = allInstruments;
                        Refresh();
                    }
                    catch (System.InvalidOperationException) { }
                    break;
                // Serializes Student Data
                case 1:
                    try
                    {
                        // New deserializer
                        XmlSerializer loader = new XmlSerializer(typeof(BindingList<StudentData>));
                        // Using statement so that it automatically closes the file
                        using (TextReader reader = new StreamReader(filepath + "\\StudentData.xml"))
                        { 
                            students = (BindingList<StudentData>)loader.Deserialize(reader);
                        }
                        Refresh();
                    }
                    catch (System.InvalidOperationException) { }
                    break;
                // Serializes employee list
                case 2:
                    try
                    {
                        // New deserializer
                        XmlSerializer loader = new XmlSerializer(typeof(BindingList<Employees>));
                        // Using statement so that it automatically closes the file
                        using (TextReader reader = new StreamReader(filepath + "\\Employees.xml"))
                        {
                            currentStaff = (BindingList<Employees>)loader.Deserialize(reader);
                        }
                        Refresh();
                    }
                    catch (System.InvalidOperationException) { }
                    break;
            }
        }

        // Sets the filepath for the program
        private void setFilepath()
        {
            if (!Directory.Exists(filepath))
                Directory.CreateDirectory(filepath);

            // If the file does not already exist, create it, otherwise, deserialize
            if (!File.Exists(filepath + "\\InstrumentData.xml"))
                File.Create(filepath + "\\InstrumentData.xml").Close();
            else deserialize(0);

            // If the file does not already exist, create it, otherwise, deserialize
            if (!File.Exists(filepath + "\\StudentData.xml"))
                File.Create(filepath + "\\StudentData.xml").Close();
            else deserialize(1);

            // If the file does not already exist, create it, otherwise, deserialize
            if (!File.Exists(filepath + "\\Employees.xml"))
            {
                File.Create(filepath + "\\Employees.xml").Close();

                // Add employee dialoge
                employeeAdd eA = new employeeAdd(0);
                eA.ShowDialog();
            }
            else deserialize(2);
        }

        // Sorts all of the instruments into their respective catagories
        public static void sortInstruments()
        {
            foreach (BindingList<Instrument> list in libraryRecords)
                list.Clear();

            // Sort
            foreach (Instrument instrument in allInstruments)
                typeSwitch(instrument);
        }

        // Adds individual insruments to their respective catagories
        public static void typeSwitch(Instrument i)
        {
            switch (i.type)
            {
                case Instrument.Catagory.Brass:
                    brass.Add(i);
                    break;
                case Instrument.Catagory.Percussion:
                    percussion.Add(i);
                    break;
                case Instrument.Catagory.Strings:
                    strings.Add(i);
                    break;
                case Instrument.Catagory.Woodwinds:
                    woodwinds.Add(i);
                    break;
                case Instrument.Catagory.EMA:
                    ema.Add(i);
                    break;
                case Instrument.Catagory.Microphone:
                    microphone.Add(i);
                    break;
                case Instrument.Catagory.Mute:
                    mute.Add(i);
                    break;
                case Instrument.Catagory.Other:
                    other.Add(i);
                    break;
            }
        }

        // Basically a custom tabindex
        private void changeIndex(object sender, EventArgs e)
        {
            switch (sender.ToString().Substring(35))
            {
                case ("All Instruments"):
                    instrumentList.DataSource = allInstruments;
                    break;
                case ("Brass"):
                    instrumentList.DataSource = brass;
                    break;
                case ("Percussion"):
                    instrumentList.DataSource = percussion;
                    break;
                case ("Strings"):
                    instrumentList.DataSource = strings;
                    break;
                case ("Woodwinds"):
                    instrumentList.DataSource = woodwinds;
                    break;
                case ("EMA"):
                    instrumentList.DataSource = ema;
                    break;
                case ("Microphone"):
                    instrumentList.DataSource = microphone;
                    break;
                case ("Mutes"):
                    instrumentList.DataSource = mute;
                    break;
                case ("Other"):
                    instrumentList.DataSource = other;
                    break;
            }
            Refresh();
        }

        // Opens the window to delete an instrument
        private void deleteButton_Click(object sender, EventArgs e)
        {
            Delete_Form delete = new Delete_Form();
            delete.ShowDialog();
        }

        // Searches through the content for a specific instrument
        private void searchButton_Click(object sender, EventArgs e)
        {
            searchResults.Clear();
            string searchText = searchBox.Text;
            searchBox.SelectAll();

            foreach (Instrument instrument in Form1.allInstruments)
            {
                // array containing all of the content in the current instrument
                string[] content = {instrument.bow.ToLower(),
                                instrument.brand.ToLower(),
                                instrument.id.ToLower(),
                                instrument.model.ToLower(),
                                instrument.name.ToLower(),
                                instrument.serialNumber.ToLower(),
                                instrument.vendor.ToLower(),
                                instrument.type.ToString(),
                                instrument.status.ToString().ToLower(),
                                instrument.cabinate.ToString()};

                // return search result if matches
                if (content.Contains(searchText.ToLower()))
                    searchResults.Add(instrument);
            }
            // Refresh datasource
            instrumentList.DataSource = searchResults;
            Refresh();
        }

        // Cancels the search
        private void cancelBox_Click(object sender, EventArgs e)
        {
            instrumentList.DataSource = allInstruments;
        }

        // Opens up the check out screen
        private void checkoutButton_Click(object sender, EventArgs e)
        {
            if (allInstruments.Count > 0)
            {
                Checkout_Data checkout = new Checkout_Data((Instrument)instrumentList.SelectedItem, Checkout.Type.checkout);
                checkout.Text = "Check Out";
                checkout.ShowDialog();
            }
            
        }

        // Opens up the check in screen
        private void checkInButton_Click(object sender, EventArgs e)
        {
            if (allInstruments.Count > 0)
            {
                Checkout_Data checkout = new Checkout_Data((Instrument)instrumentList.SelectedItem, Checkout.Type.checkin);
                checkout.Text = "Check In";
                checkout.ShowDialog();
            }
        }

        // Opens the check in/out log
        private void checkLogButton_Click(object sender, EventArgs e)
        {
            checkOutInLog check = new checkOutInLog((Instrument)instrumentList.SelectedItem);
            check.ShowDialog();
        }

        // Marks the instrument as missing
        private void missingButton_Click(object sender, EventArgs e)
        {
            if (allInstruments.Count > 0)
            {
                // Finds the id of the selected instrument
                Instrument tempI = (Instrument)instrumentList.SelectedItem;
                string i = tempI.id;

                foreach (Instrument instrument in allInstruments)
                {
                    if (instrument.id.Equals(i))
                    {
                        switch (instrument.status)
                        {
                            case Instrument.Status.Missing:
                                instrument.status = (Instrument.Status)1;
                                break;
                            case Instrument.Status.Found:
                                instrument.status = (Instrument.Status)0;
                                break;
                        }
                    }

                    // Creates a new Binding list for Datasource because otherwise it doesn't
                    // work for some reason
                    BindingList<Instrument> tempB = new BindingList<Instrument>();
                    tempB.Add(instrument);
                    instrumentList.DataSource = tempB;
                    break;
                }

                sortInstruments();
                Refresh();
            }
        }

        // Exports instrument data to csv file
        private void csvExportButton_Click(object sender, EventArgs e)
        {
            if (allInstruments.Count > 0)
                csvExporter.export(filepath + "\\exportedLibrary.csv");
        }

        // Opens up add employees winform
        private void addEmployeesButton_Click(object sender, EventArgs e)
        {
            employeeAdd aE = new employeeAdd(0);
            aE.ShowDialog();
        }

        // Opens up change employee winform
        private void changeEmployeeButton_Click(object sender, EventArgs e)
        {
            if (Form1.currentStaff.Count > 0)
            {
                employeeSelect eS = new employeeSelect();
                eS.ShowDialog();
            }
            else
            {
                employeeAdd aE = new employeeAdd(1);
                aE.ShowDialog();
            }
        }

        // Search function for scanner
        private void searchBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)13)
                searchButton_Click(sender, e);
        }

        // Import backup
        private void importButton_Click(object sender, EventArgs e)
        {
            askBackupForm aBF = new askBackupForm();
            aBF.ShowDialog();

            backupFunction.checkBackup(filepath);
            populateBackup(filepath + "\\Backups");
        }

        // Read from backup into the RAM
        private void populateBackup(string fP)
        {
                // Empty the binding lists
                foreach (BindingList<Instrument> list in libraryRecords)
                    list.Clear();
                
                // If the backup is going to happen
                if(backupStatus)
                    // Deserialize all of the information
                    for (int i = 0; i <= 2; i++)
                        deserialize(i);

            backupStatus = false;
        }

        // When form is closing
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Perform backup if necessary
            backupFunction.performBackup(filepath);
        }
    }
}
