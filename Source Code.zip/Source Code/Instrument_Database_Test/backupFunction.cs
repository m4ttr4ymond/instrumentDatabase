﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Compression;

namespace Instrument_Database_Test
{
    class backupFunction
    {
        public static DateTime lastBackup = DateTime.Parse("1-1-2000");

        public static void performBackup(string filepath)
        {
            directoryCheck(filepath);
            readBackupTime(filepath);
            //saveBackupTime(filepath);
            
        }

        static void directoryCheck(string fP)
        {
            string filepath = fP + "\\Backups";

            if (!Directory.Exists(filepath))
                Directory.CreateDirectory(filepath);
        }

        static void readBackupTime(string filepath)
        {
            DateTime mostRecentBackup = DateTime.Parse("1/1/2000");
            if (Directory.Exists(filepath + "\\Backups"))
            {
                DateTime temp = DateTime.Now;
                foreach (string backup in Directory.GetFiles(filepath + "\\Backups", "instrumentLibraryBackup_*.zip"))
                {
                    if (DateTime.TryParse(backup.Remove(backup.LastIndexOf(".")).Substring(backup.LastIndexOf("_") + 1), out temp))
                        if (temp.CompareTo(mostRecentBackup) > 0)
                            mostRecentBackup = temp;
                }
            }

            if (mostRecentBackup.AddDays(14).CompareTo(DateTime.Now) < 0)
                backupRun(filepath);
        }

        static void backupRun(string fP)
        {
            string filepath = fP + "\\Backups\\instrumentLibraryBackup_" + DateTime.Now.ToShortDateString().Replace("/", "-");
            Directory.CreateDirectory(filepath);
            foreach (string file in Directory.GetFiles(fP, "*.xml"))
            {
                if (File.Exists(filepath + file.Substring(file.LastIndexOf("\\"))))
                {
                    File.Delete(filepath + file.Substring(file.LastIndexOf("\\")));
                }
                File.Copy(file, filepath + file.Substring(file.LastIndexOf("\\")));
            }

            ZipFile.CreateFromDirectory(filepath, filepath + ".zip");
            Console.WriteLine(filepath);
            foreach (string file in Directory.GetFiles(filepath))
            {
                File.Delete(file);
            }
            Directory.Delete(filepath);
        }

        //------------------------------------------------------//

        public static void checkBackup(string fP)
        {
            string filepath = fP + "\\Backups";
            DateTime temp = DateTime.Now;
            string newestBackup = "";

            DateTime mostRecentBackup = DateTime.Parse("1/1/2000");
            if (Directory.Exists(filepath))
            {
                foreach (string file in Directory.GetFiles(filepath, "instrumentLibraryBackup_*.zip"))
                {
                    string timeHolder = file.Remove(file.LastIndexOf(".")).Substring(file.LastIndexOf("_")+1);
                    if (DateTime.TryParse(timeHolder, out temp))
                        if (temp.CompareTo(mostRecentBackup) > 0)
                        {
                            mostRecentBackup = temp;
                            newestBackup = file;
                        }
                            
                }

                if (newestBackup != "")
                {
                    foreach (string file in Directory.GetFiles(fP, "*.xml"))
                        File.Delete(file);

                    ZipFile.ExtractToDirectory(newestBackup, fP);
                }
            }
        }
    }
}
