﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Instrument_Database_Test
{
    // Winform for filling out instrument information
    public partial class Data_Form : Form
    {
        public Data_Form()
        {
            InitializeComponent();

            // List of catagories
            BindingList<Instrument.Catagory> catagories =
                new BindingList<Instrument.Catagory> { (Instrument.Catagory) 0,
                                                       (Instrument.Catagory) 1,
                                                       (Instrument.Catagory) 2,
                                                       (Instrument.Catagory) 3,
                                                       (Instrument.Catagory) 4,
                                                       (Instrument.Catagory) 5,
                                                       (Instrument.Catagory) 6,
                                                       (Instrument.Catagory) 7};
            
            // Populate catagoryBox
            catagoryBox.DataSource = catagories;
            catagoryBox.Select();
            errorLabel.Text = "";
            nameBox.Select();
            Refresh();
        }

        // Save information to file
        private void saveNewButton_Click(object sender, EventArgs e)
        {
            int cabinate = 0;
            int value = 0;

            if (nameBox.Text != "" & idBox.Text != "")
            {
                // Checks to make sure that the user entered numbers where necessary
                if (Int32.TryParse(cabinateBox.Text, out cabinate) && Int32.TryParse(valueBox.Text, out value))
                {
                    // If the bow box is empty, fill with N/A
                    switch (bowBox.Text)
                    {
                        case "":
                            bowBox.Text = "N/A";
                            break;
                    }

                    // Create new instrument
                    Instrument temp = new Instrument((Instrument.Catagory)catagoryBox.SelectedIndex, cabinate,
                                                    nameBox.Text, idBox.Text, bowBox.Text, brandBox.Text, modelBox.Text, vendorBox.Text,
                                                    serialNumBox.Text, Int32.Parse(valueBox.Text), noteBox.Text);

                    // Add instrument to allInstruments
                    Form1.allInstruments.Add(temp);
                    // Send to the appropriate catagory list
                    Form1.typeSwitch(temp);
                    Close();
                }
                else errorLabel.Text = "You need to enter your number\nvalues as integers.";
            }
            else errorLabel.Text = "You are missing either the\ninstrument name or ID.";
            
        }

        // Cancel button
        private void cancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
