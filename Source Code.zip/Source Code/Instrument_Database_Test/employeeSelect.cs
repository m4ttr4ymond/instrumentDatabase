﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Instrument_Database_Test
{
    // Winform for selecting the current employee
    public partial class employeeSelect : Form
    {
        // "Constructor"
        public employeeSelect()
        {
            InitializeComponent();

            // Set datasource
            employeeBox.DataSource = Form1.currentStaff.OrderBy(x => x.eName.Substring(x.eName.LastIndexOf(" ")+1))
                                         .ToList<Employees>();
            employeeBox.ClearSelected();

            try
            {
                // Select nothing
                employeeBox.SetSelected(Form1.currentStaff.Count - 1, true);
            }
            // If file is corrupted
            catch (Exception)
            {
                // Make new file
                File.Delete(Form1.filepath + "\\Employees.xml");
                File.Create(Form1.filepath + "\\Employees.xml");
            }
            
            Refresh();
        }

        // On double click, the form is closed, which triggers automatic selection
        private void selectItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void employeeSelect_FormClosed(object sender, FormClosedEventArgs e)
        {
            // If someone is selected
            if (employeeBox.SelectedIndex >= 0)
                // Set to chosen employee
                Form1.currentEmployee = employeeBox.SelectedItem.ToString();
            // Otherwise
            else
                // Set to other
                Form1.currentEmployee = "";
        }

        // If the user chooses "other"
        private void otherButton_Click(object sender, EventArgs e)
        {
            // Clear selection, which will default to "Other"
            employeeBox.ClearSelected();
            Close();
        }
    }
}
