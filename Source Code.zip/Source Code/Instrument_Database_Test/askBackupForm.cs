﻿using System;
using System.Windows.Forms;

namespace Instrument_Database_Test
{
    // Asks the user if they want to do the backup
    public partial class askBackupForm : Form
    {
        public askBackupForm()
        {
            InitializeComponent();
        }

        private void continueButton_Click(object sender, EventArgs e)
        {
            Form1.backupStatus = true;
            Close();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
